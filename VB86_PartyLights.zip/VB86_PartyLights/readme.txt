/*
 * R e a d m e
 * -----------
 * VB86_PartyLights
 * By VeganBurrito86
 * 
 * Install by copying the "VB86_PartyLights" folder into your "%AppData%\Roaming\SpaceEngineers\IngameScripts\local" folder.
 * 
 * In game, just load the script into a programmable block. Run with the Argument "Help" for help with the options.
 * 
 */